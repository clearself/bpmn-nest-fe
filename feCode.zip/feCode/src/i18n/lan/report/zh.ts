export default {
  report: {
    columns: {
      num: '访问量',
      path: '页面路径',
      url: '页面全路径',
      createTime: '首次访问时间',
      updateTime: '最近一次访问时间',
      remark: '页面标题'
    }
  }
}
