export default {
  report: {
    columns: {
      num: 'Visits',
      path: 'Page path',
      url: 'Page full path',
      createTime: 'First visit time',
      updateTime: 'Last visit time',
      remark: 'Page title'
    }
  }
}
