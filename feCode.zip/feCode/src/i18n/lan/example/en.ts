export default {
  example: {
    columns: {
      name: 'Name',
      content: 'Content'
    },
    table: {
      logisticsCompanyName: 'Logistic company name',
      logisticsMethods: 'Logistics methods',
      contacts: 'Contacts',
      contactInformation: 'Contact information',
      logisticsTrackingNumber: 'Logistics tracking number',
      licensePlateNumber: 'License plate number',
      deliveryNo: 'Delivery note no',
      remark: 'Remark'
    }
  }
}
