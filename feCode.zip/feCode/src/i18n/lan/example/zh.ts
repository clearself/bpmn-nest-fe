export default {
  example: {
    columns: {
      name: '名称',
      content: '内容'
    },
    table: {
      logisticsCompanyName: '物流公司名称',
      logisticsMethods: '物流方式',
      contacts: '联系人',
      contactInformation: '联系方式',
      logisticsTrackingNumber: '物流单号',
      licensePlateNumber: '车牌号',
      deliveryNo: '送货单号',
      remark: '备注'
    }
  }
}
