export default {
  logininfo: {
    columns: {
      visitNo: '访问编号',
      userName: '用户名称',
      address: '登录地址',
      location: '登录地点',
      system: '操作系统',
      browser: '浏览器',
      state: '登录状态',
      desc: '描述',
      visitTime: '访问时间'
    }
  }
}
