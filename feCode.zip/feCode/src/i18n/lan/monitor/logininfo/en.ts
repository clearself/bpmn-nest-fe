export default {
  logininfo: {
    columns: {
      visitNo: 'Access no',
      userName: 'User name',
      address: 'Login address',
      location: 'Login location',
      system: 'Operating system',
      browser: 'Browser',
      state: 'Login status',
      desc: 'Description',
      visitTime: 'Access time'
    }
  }
}
