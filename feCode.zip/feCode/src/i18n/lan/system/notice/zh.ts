export default {
  notice: {
    columns: {
      noticeTitle: '公告标题',
      noticeType: '公告类型',
      createBy: '创建者',
      noticeContent: '内容',
      state: '状态',
      createTime: '创建时间'
    }
  }
}
