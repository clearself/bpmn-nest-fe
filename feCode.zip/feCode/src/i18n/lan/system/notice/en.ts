export default {
  notice: {
    columns: {
      noticeTitle: 'Announcement title',
      noticeType: 'Announcement type',
      createBy: 'Creator',
      noticeContent: 'Content',
      state: 'state',
      createTime: 'Creation time',
      remark: 'Remark'
    }
  }
}
