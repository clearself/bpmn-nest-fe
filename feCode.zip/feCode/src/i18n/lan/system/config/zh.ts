export default {
  config: {
    columns: {
      configName: '参数名称',
      configKey: '参数键名',
      configValue: '参数键值',
      configType: '系统内置',
      state: '状态',
      createTime: '创建时间',
      remark: '备注'
    }
  }
}
