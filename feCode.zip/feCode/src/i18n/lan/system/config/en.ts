export default {
  config: {
    columns: {
      configName: 'Parameter',
      configKey: 'Parameter key names',
      configValue: 'Parameter key value',
      configType: 'Built in system',
      state: 'state',
      createTime: 'Creation time',
      remark: 'Remark'
    }
  }
}
