export default {
  dept: {
    columns: {
      deptName: 'Department name',
      preDeptName: 'Superior department',
      showSort: 'Display sorting',
      leader: 'Leader',
      phone: 'Phone',
      email: 'Email',
      deptState: 'Department status',
      sort: 'sort',
      state: 'state',
      createTime: 'Creation time'
    }
  }
}
