export default {
  dept: {
    columns: {
      deptName: '部门名称',
      preDeptName: '上级部门',
      showSort: '显示排序',
      leader: '负责人',
      phone: '联系电话',
      email: '邮箱',
      deptState: '部门状态',
      sort: '排序',
      state: '状态',
      createTime: '创建时间'
    }
  }
}
