export default {
  user: {
    columns: {
      userName: '用户名称',
      password: '用户密码',
      nickName: '用户昵称',
      deptName: '部门',
      phonenumber: '手机号码',
      state: '状态',
      createTime: '创建时间',
      remark: '备注',
      beDeptName: '归属部门',
      email: '邮箱',
      sex: '用户性别',
      post: '岗位',
      role: '角色'
    }
  }
}
