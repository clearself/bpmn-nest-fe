export default {
  user: {
    columns: {
      userName: 'User name',
      password: 'Password',
      nickName: 'Nick name',
      deptName: 'Department',
      phonenumber: 'Phonen umber',
      state: 'state',
      createTime: 'Creation time',
      remark: 'Remark',
      beDeptName: 'Belonging department',
      email: 'Email',
      sex: 'Sex',
      post: 'Post',
      role: 'Role'
    }
  }
}
