export default {
  post: {
    columns: {
      postNo: 'Post no',
      postCode: 'Post code',
      postName: 'Post name',
      postSort: 'Post ranking',
      state: 'state',
      createTime: 'Creation time',
      remark: 'Remark'
    }
  }
}
