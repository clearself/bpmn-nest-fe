export default {
  post: {
    columns: {
      postNo: '岗位编号',
      postCode: '岗位编码',
      postName: '岗位名称',
      postSort: '岗位排序',
      state: '状态',
      createTime: '创建时间',
      remark: '备注'
    }
  }
}
