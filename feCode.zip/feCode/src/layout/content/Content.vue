<template>
  <div class="p-1 w100 router-wrapper">
    <router-view />
  </div>
</template>
<script lang="ts" setup scoped></script>
<style lang="scss" scoped>
.router-wrapper {
  box-sizing: border-box;
}
</style>
