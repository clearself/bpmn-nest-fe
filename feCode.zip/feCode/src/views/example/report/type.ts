export type deleteItemProp = {
  id: string
}

export type saveDataProp = {
  noticeId?: string
  noticeTitle: string
  noticeType?: number
  status?: string
  noticeContent?: string
}
