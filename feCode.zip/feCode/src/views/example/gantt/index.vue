<template>
  <div style="height: 100%; background-color: white">
    <Gatt1 />
    <!-- <Gatt2 /> -->
  </div>
</template>

<script setup lang="ts">
import Gatt1 from './Gatt1.vue'
// import Gatt2 from './Gatt2.vue'
</script>
<style lang="scss" scoped></style>
