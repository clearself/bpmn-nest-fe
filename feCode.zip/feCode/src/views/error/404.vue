<script lang="ts" setup></script>
<template>
  <div class="ub w100 ub-ver ub-ac ub-pc">
    <icon-svg name="404" width="500" height="500" />
    <router-link to="/">
      <a-button type="primary" style="width: 200px">回到首页</a-button>
    </router-link>
  </div>
</template>

<style lang="scss" scoped></style>
