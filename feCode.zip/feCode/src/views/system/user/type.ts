export type deleteItemProp = {
  id: string
}
